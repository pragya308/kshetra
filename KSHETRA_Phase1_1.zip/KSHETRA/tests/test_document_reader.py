from backend.rag.document_reader import SUPPORTED_FILES
from backend.rag.ingestion import chunk_text
def test_supported_image_types():
    assert {'.png','.jpg','.jpeg','.webp'}.issubset(SUPPORTED_FILES)
def test_supported_document_types():
    assert {'.pdf','.docx','.html','.csv','.txt'}.issubset(SUPPORTED_FILES)
def test_chunk_metadata_for_image_source():
    c=chunk_text('Band n78 | 3500 MHz | 58 dBm','example_table.png')
    assert c[0]['source']=='example_table.png' and c[0]['doc_type']=='png'
