import re
PHONE=re.compile(r"(?<!\d)(?:\+?\d[\d\s()-]{7,}\d)(?!\d)")
def mask_pii(text: str)->str:
    return PHONE.sub("[PHONE_REDACTED]",text)
