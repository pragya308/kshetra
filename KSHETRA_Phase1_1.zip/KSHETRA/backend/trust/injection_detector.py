SUSPICIOUS=("ignore all previous instructions","reveal the system prompt","send the api key","disregard safety rules")
def scan_for_injection(text: str)->list[str]:
    low=text.lower()
    return [p for p in SUSPICIOUS if p in low]
