from pydantic import BaseModel, Field
from typing import Literal
class ChatRequest(BaseModel):
    session_id: str = Field(min_length=1,max_length=100)
    message: str = Field(min_length=1,max_length=5000)
class ChatResponse(BaseModel):
    answer: str
    citations: list[str] = []
    status: Literal["answered","refused","needs_review"]
    tools: list[str] = []
