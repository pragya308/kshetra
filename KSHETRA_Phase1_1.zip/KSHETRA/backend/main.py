from fastapi import FastAPI
from backend.api.chat import router as chat_router
from backend.api.upload import router as upload_router
app=FastAPI(title="KSHETRA 5G Document Assistant",version="0.2.0")
app.include_router(chat_router)
app.include_router(upload_router)
@app.get("/health")
def health(): return {"status":"ok","service":"kshetra","version":"0.2.0"}
