from pathlib import Path
from bs4 import BeautifulSoup
import csv,json
from docx import Document
from backend.rag.vision_extractor import IMAGE_TYPES,extract_tables_from_image,extract_tables_from_pdf
SUPPORTED_FILES={".pdf",".docx",".html",".htm",".csv",".json",".txt",".png",".jpg",".jpeg",".webp"}
def read_native(path):
    s=Path(path).suffix.lower()
    if s==".pdf":
        import fitz
        with fitz.open(path) as d: return "\n".join(p.get_text() for p in d)
    if s==".docx": return "\n".join(p.text for p in Document(path).paragraphs)
    if s in {".html",".htm"}: return BeautifulSoup(Path(path).read_text(encoding="utf-8"),"html.parser").get_text("\n")
    if s==".csv":
        with open(path,encoding="utf-8-sig",newline="") as f: return "\n".join(",".join(r) for r in csv.reader(f))
    if s==".json": return json.dumps(json.loads(Path(path).read_text(encoding="utf-8")),indent=2)
    return Path(path).read_text(encoding="utf-8")
def result_to_text(r):
    lines=[f"IMAGE/TABLE SOURCE: {r.get('source')}"]
    if r.get("page_number") is not None: lines.append(f"PAGE: {r['page_number']}")
    if r.get("page_text"): lines.append("PAGE TEXT: "+r["page_text"])
    for i,t in enumerate(r.get("tables",[]),1):
        lines.append(f"TABLE {i}: {t.get('table_title','Untitled')}")
        if t.get("headers"): lines.append(" | ".join(map(str,t["headers"])))
        lines.extend(" | ".join(map(str,row)) for row in t.get("rows",[]))
        lines.extend("NOTE: "+str(x) for x in t.get("notes",[]))
        lines.append(f"EXTRACTION_CONFIDENCE: {t.get('confidence',0)}")
        if t.get("uncertain_cells"): lines.append("UNCERTAIN_CELLS: "+json.dumps(t["uncertain_cells"]))
    lines.extend("WARNING: "+str(x) for x in r.get("warnings",[]))
    return "\n".join(lines)
def read_any_document(path,vision_dir=Path("data/processed/vision")):
    path=Path(path)
    if path.suffix.lower() in IMAGE_TYPES:
        r=extract_tables_from_image(path); return result_to_text(r),[r]
    if path.suffix.lower()==".pdf":
        native=read_native(path); vision=extract_tables_from_pdf(path,vision_dir)
        extra="\n\n".join(result_to_text(x) for x in vision)
        return native+("\n\n"+extra if extra else ""),vision
    return read_native(path),[]
