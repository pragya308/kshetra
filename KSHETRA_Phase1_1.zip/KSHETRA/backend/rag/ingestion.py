from pathlib import Path
import json
from backend.rag.document_reader import read_any_document,SUPPORTED_FILES
RAW=Path("data/raw")
def chunk_text(text,source,max_chars=900,overlap=120):
    text="\n".join(x.strip() for x in text.splitlines() if x.strip()); out=[]; start=0
    while start<len(text):
        end=min(start+max_chars,len(text))
        if end<len(text):
            b=text.rfind(" ",start,end)
            if b>start+max_chars//2: end=b
        body=text[start:end].strip()
        if body: out.append({"id":f"{Path(source).stem}-{len(out)+1:04d}","text":body,"source":source,
          "doc_type":Path(source).suffix.lower().lstrip("."),
          "status":"superseded" if "older" in source.lower() else "current"})
        start=max(end-overlap,start+1)
    return out
def ingest_folder(folder=RAW):
    chunks=[]
    for path in sorted(Path(folder).iterdir()):
        if not path.is_file() or path.suffix.lower() not in SUPPORTED_FILES: continue
        try:
            text,vision=read_any_document(path)
            for c in chunk_text(text,path.name):
                c["extraction_method"]="vision_plus_text" if vision else "native_text"; c["needs_review"]=bool(vision); chunks.append(c)
            if vision:
                out=Path("data/processed/vision"); out.mkdir(parents=True,exist_ok=True)
                (out/f"{path.stem}_vision.json").write_text(json.dumps(vision,indent=2),encoding="utf-8")
        except Exception as e: print(f"WARNING: {path.name}: {type(e).__name__}: {e}")
    return chunks
if __name__=="__main__":
    c=ingest_folder(); Path("data/processed/chunks.json").write_text(json.dumps(c,indent=2),encoding="utf-8"); print(f"Ingested {len(c)} chunks from {RAW}")
