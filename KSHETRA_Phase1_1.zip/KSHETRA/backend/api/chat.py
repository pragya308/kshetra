from fastapi import APIRouter, HTTPException
from openai import OpenAI
from backend.config import settings
from backend.trust.schemas import ChatRequest,ChatResponse
from backend.trust.pii_masker import mask_pii
from backend.trust.injection_detector import scan_for_injection
from backend.rag.ingestion import ingest_folder
from pathlib import Path
import json

router=APIRouter()
client=OpenAI(api_key=settings.openai_api_key) if settings.openai_api_key else None

@router.post("/chat",response_model=ChatResponse)
def chat(req: ChatRequest):
    question=mask_pii(req.message)
    if scan_for_injection(question):
        return ChatResponse(answer="I cannot follow instructions embedded in user-provided content. Please ask a technical question about the supplied 5G documents.",status="refused",tools=["pii_masking","injection_scan"])
    if client is None:
        raise HTTPException(status_code=503,detail="OPENAI_API_KEY is not configured. Copy .env.example to .env and add your key.")
    cache_path=Path("data/processed/chunks.json")
    if cache_path.exists():
        chunks=json.loads(cache_path.read_text(encoding="utf-8"))
    else:
        chunks=ingest_folder()
        cache_path.parent.mkdir(parents=True,exist_ok=True)
        cache_path.write_text(json.dumps(chunks,indent=2),encoding="utf-8")
    terms={w.lower().strip(".,?!:;()[]") for w in question.split() if len(w)>2}
    ranked=[]
    for c in chunks:
        score=sum(1 for term in terms if term in c["text"].lower())
        if score: ranked.append((score,c))
    ranked.sort(key=lambda x:x[0],reverse=True)
    selected=ranked[:5]
    if not selected:
        return ChatResponse(answer="I could not find evidence in the fictional knowledge base. I will not guess; please provide the vendor, band or relevant document.",status="needs_review",tools=["ingestion","baseline_lexical_retrieval"])
    context="\n\n".join(f"[{c['source']} | {c['id']}]\n{c['text']}" for _,c in selected)
    prompt=f"""You are KSHETRA, a cautious assistant for a fictional 5G training corpus.
Answer only from the supplied context. Never invent a parameter, unit, band or regulatory limit.
If sources conflict, state the conflict. Do not claim a vendor value is a regulatory limit.
Always include units. Preserve relevant WARNING text.
Cite factual claims as [source | chunk-id]. If evidence is insufficient, say so.
CONTEXT:\n{context}\nQUESTION: {question}"""
    try:
        result=client.chat.completions.create(model=settings.openai_model,messages=[{"role":"user","content":prompt}],temperature=0)
        answer=result.choices[0].message.content or "No answer returned."
    except Exception as e:
        raise HTTPException(status_code=502,detail=f"LLM request failed: {type(e).__name__}: {e}")
    citations=sorted({c["source"] for _,c in selected if c["source"] in answer})
    return ChatResponse(answer=answer,citations=citations,status="answered" if citations else "needs_review",
                        tools=["pii_masking","injection_scan","document_ingestion","baseline_lexical_retrieval","openai_generation"])
