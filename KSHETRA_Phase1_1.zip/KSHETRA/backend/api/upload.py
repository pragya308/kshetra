from pathlib import Path
from fastapi import APIRouter,UploadFile,File,HTTPException
from backend.rag.ingestion import ingest_folder, chunk_text
from backend.rag.document_reader import read_any_document
from backend.rag.document_reader import SUPPORTED_FILES
import json
router=APIRouter(); RAW=Path("data/raw"); MAX_BYTES=20*1024*1024
@router.post("/upload")
async def upload_document(file: UploadFile=File(...)):
    name=Path(file.filename or "uploaded_file").name; suffix=Path(name).suffix.lower()
    if suffix not in SUPPORTED_FILES: raise HTTPException(415,detail="Unsupported file type.")
    RAW.mkdir(parents=True,exist_ok=True); dest=RAW/name
    if dest.exists(): raise HTTPException(409,detail="File already exists. Rename it before uploading.")
    size=0
    try:
        with dest.open("wb") as out:
            while True:
                block=await file.read(1024*1024)
                if not block: break
                size+=len(block)
                if size>MAX_BYTES:
                    dest.unlink(missing_ok=True); raise HTTPException(413,detail="File exceeds 20 MB limit.")
                out.write(block)
        processed=Path("data/processed"); processed.mkdir(parents=True,exist_ok=True)
        cache=processed/"chunks.json"
        if cache.exists():
            chunks=json.loads(cache.read_text(encoding="utf-8"))
        else:
            chunks=ingest_folder()
            cache.write_text(json.dumps(chunks,indent=2),encoding="utf-8")
        # Process only the newly uploaded file; do not re-run paid vision extraction
        # on previously uploaded images on every subsequent upload.
        extracted_text, vision_results=read_any_document(dest)
        new_chunks=chunk_text(extracted_text,name)
        for chunk in new_chunks:
            chunk["extraction_method"]="vision_plus_text" if vision_results else "native_text"
            chunk["needs_review"]=bool(vision_results)
        chunks=[c for c in chunks if c.get("source") != name] + new_chunks
        if vision_results:
            vision_dir=processed/"vision"; vision_dir.mkdir(parents=True,exist_ok=True)
            (vision_dir/f"{dest.stem}_vision.json").write_text(json.dumps(vision_results,indent=2),encoding="utf-8")
        cache.write_text(json.dumps(chunks,indent=2),encoding="utf-8")
        return {"filename":name,"bytes":size,"status":"uploaded_and_ingested",
          "chunk_count":sum(c["source"]==name for c in chunks),
          "extraction":"vision" if suffix in {".png",".jpg",".jpeg",".webp",".pdf"} else "native_file_reader",
          "review_required":suffix in {".png",".jpg",".jpeg",".webp",".pdf"}}
    except HTTPException: raise
    except Exception as e:
        dest.unlink(missing_ok=True); raise HTTPException(500,detail=f"Processing failed: {type(e).__name__}: {e}")
    finally: await file.close()
