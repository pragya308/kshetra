from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    openai_api_key: str = ""
    openai_model: str = "gpt-4.1-mini"
    openai_embedding_model: str = "text-embedding-3-small"
    app_env: str = "local"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
settings = Settings()
