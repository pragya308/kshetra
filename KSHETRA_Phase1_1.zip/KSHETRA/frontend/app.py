import streamlit as st,requests,uuid
st.set_page_config(page_title="KSHETRA | 5G Assistant",page_icon="📡",layout="wide")
st.title("📡 KSHETRA")
st.caption("5G Deployment Document Assistant · Document and image reading enabled")
API="http://localhost:8000"
if "sid" not in st.session_state: st.session_state.sid=str(uuid.uuid4())
if "history" not in st.session_state: st.session_state.history=[]
with st.sidebar:
    st.subheader("Knowledge Base")
    up=st.file_uploader("Upload document or image",type=["pdf","docx","html","htm","csv","json","txt","png","jpg","jpeg","webp"])
    if up and st.button("Upload and process",type="primary"):
        with st.spinner("Reading document and extracting tables..."):
            try:
                r=requests.post(f"{API}/upload",files={"file":(up.name,up.getvalue(),up.type or "application/octet-stream")},timeout=180)
                r.raise_for_status(); st.success(f"Processed {up.name}"); st.json(r.json())
            except Exception as e: st.error(f"Upload failed: {e}")
    st.caption("Vision-extracted tables are drafts and require human verification.")
    if st.button("Clear conversation"): st.session_state.history=[]; st.rerun()
for m in st.session_state.history:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])
        if m.get("tools"):
            with st.expander("Tool activity"): st.write(m["tools"])
q=st.chat_input("Ask about a 5G parameter, band, warning or uploaded document...")
if q:
    st.session_state.history.append({"role":"user","content":q})
    with st.chat_message("user"): st.markdown(q)
    with st.chat_message("assistant"):
        with st.spinner("Retrieving evidence..."):
            try:
                r=requests.post(f"{API}/chat",json={"session_id":st.session_state.sid,"message":q},timeout=120); r.raise_for_status()
                d=r.json(); st.markdown(d["answer"]); st.caption("Status: "+d["status"])
                with st.expander("Tool activity"): st.write(d["tools"])
                if d["citations"]: st.caption("Sources: "+", ".join(d["citations"]))
                st.session_state.history.append({"role":"assistant","content":d["answer"],"tools":d["tools"]})
            except Exception as e: st.error(f"Request failed: {e}")
